module.exports = 'Jurisdicción y competencia'
