<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5 
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/1.svg")
            .col-lg
              p.mb-0 El conocimiento de los conceptos de jurisdicción y competencia, es fundamental para la correcta aplicación del Derecho Procesal en el contexto judicial. Esta unidad aborda el alcance de la jurisdicción como manifestación del poder del Estado, para administrar justicia, y examina los diversos criterios que permiten determinar la competencia de los jueces en los diferentes asuntos sometidos a su conocimiento. Se analizan las reglas legales que regulan estos aspectos, así como los mecanismos que resuelven los conflictos de competencia, e impiden la actuación de jueces en situaciones de impedimento o recusación.

        p(data-aos="fade-down") Al finalizar la unidad, se espera que el estudiante aplique los principios procesales relativos a la jurisdicción y la competencia, identifique los factores que determinan la competencia judicial y analice las situaciones que dan lugar a conflictos competenciales, reparto judicial, impedimentos y recusaciones, interpretando adecuadamente, su regulación, conforme al ordenamiento jurídico colombiano. 
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/2.png", data-aos="zoom-in")    

    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/3.png", data-aos="zoom-in")       
      .col-lg-8
        .bg-color-3.p-4.mb-4(data-aos="fade-left")
          p.mb-0 Esta temática reviste especial importancia en la formación jurídica, dado que el desconocimiento de las reglas de competencia puede acarrear nulidades procesales, decisiones inválidas o vulneraciones al debido proceso. Dominar estos conceptos permite al futuro profesional del Derecho orientar, de manera adecuada, los procedimientos judiciales, velar por la legalidad en la asignación de asuntos y actuar conforme a las garantías procesales.
        p(data-aos="fade-down") La unidad se organiza en cinco ejes temáticos. 

    .row.justify-content-center.mb-5  
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/4.svg")
            .col-lg
              h5 Primer eje
              p.mb-0 La noción de jurisdicción como función pública del Estado.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-down")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/5.svg")
            .col-lg
              h5 Segundo eje
              p.mb-0 Las reglas legales para determinar la competencia por materia, cuantía, territorio y función.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-right")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/6.svg")
            .col-lg
              h5 Tercer eje
              p.mb-0 Los mecanismos de reparto judicial.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/7.svg")
            .col-lg
              h5 Cuarto eje 
              p.mb-0 Los conflictos de competencia y sus procedimientos de resolución.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-right")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/8.svg")
            .col-lg
              h5 Quinto eje
              p.mb-0 El régimen de impedimentos y recusaciones como salvaguarda de la imparcialidad judicial.
                                                                      
    .row
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/9.png", data-aos="zoom-in")              
      .col-lg-8 
        .bg-color-3.p-4.j1.h-100(data-aos="fade-left")
          p Las actividades incluyen el análisis de normas procesales, estudio de casos, ejercicios prácticos y participación en foro.

          p.mb-0 Se invita a asumir un rol activo y reflexivo frente a los contenidos, a consultar permanentemente la legislación procesal vigente, y a resolver las actividades propuestas con rigor argumentativo. Esta unidad proporciona competencias clave para desenvolverse con solvencia en el ejercicio jurídico y avanzar con profundidad en el estudio del proceso judicial colombiano.                 
</template>
