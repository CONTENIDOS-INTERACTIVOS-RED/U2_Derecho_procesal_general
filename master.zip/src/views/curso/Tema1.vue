<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'1. Jurisdicción y función jurisdiccional del Estado'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    p(data-aos="fade-down") Para conocer qué es la jurisdicción y la función jurisdiccional del Estado, lo invitamos a ver el siguiente video.
    .bg-full-width.bg-fondo-slider.mb-5(data-aos="fade-right")
      .p-4.p-md-5
        figure
          .video
            iframe(width="560" height="315" src="https://www.youtube.com/embed/YzLY2FciRdc?si=FK38KGg51kuN7POS" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen) 
            
    #t_1_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 1.1] Concepto de jurisdicción y función jurisdiccional del Estado

    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/10.png", data-aos="zoom-in")       
      .col-lg-8
        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/11.svg")
            .col-lg
              p.mb-0 La jurisdicción, en el contexto del Derecho Procesal, es uno de los conceptos centrales para comprender cómo funciona el sistema judicial dentro del Estado de Derecho. Se entiende como la expresión del poder soberano del Estado para administrar justicia, es decir, para conocer de los conflictos jurídicos que surgen entre los ciudadanos o entre estos y el propio Estado, y resolverlos mediante decisiones que tienen fuerza vinculante. La etimología del término ayuda a entender su esencia. Proviene del latín jurisdictio, que significa decir el derecho, lo cual implica declarar lo que es conforme a derecho en un caso concreto y hacer que se respete lo decidido (Cifuentes Muñoz, 2006).

    .row.justify-content-center.mb-5      
      .col-lg-9.mb-3.mb-lg-0  
        .bg-color-8.p-5.mb-4.j1(data-aos="fade-left")
          p Esta función jurisdiccional #[b no se ejerce de manera difusa ni arbitraria]. Por el contrario, está institucionalizada. Se encuentra en manos de jueces y tribunales legalmente establecidos, que actúan conforme a procedimientos previamente definidos en el ordenamiento jurídico.

          p.mb-0 En Colombia, esta facultad está reconocida expresamente en el Artículo 116 de la Constitución Política, que establece que la jurisdicción #[b la ejercen los jueces de la República] y, en determinados casos, algunos particulares autorizados por la ley como árbitros o conciliadores.
        p(data-aos="fade-down") La función jurisdiccional comprende dos actos fundamentales: 

      .col-lg-3
        figure
          img.img-a.img-t(src="@/assets/curso/temas/12.png", data-aos="zoom-in")

    .bg-full-width-1.bg-fondo-1.py-4
      .px-4.px-md-5
        .row.justify-content-center.align-items-stretch.text-center.mb-4
          .col-lg-6.mb-4(data-aos="zoom-in-up")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/13.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center Juzgar
                p.mb-0 Se refiere a la potestad del juez para analizar los hechos de un caso, interpretarlos jurídicamente y emitir una sentencia que resuelva el conflicto.
          .col-lg-6.mb-4(data-aos="zoom-in-down")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/14.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center Hacer ejecutar lo juzgado
                p.mb-0 Implica que esa decisión no es una simple declaración de voluntad, sino una resolución que debe cumplirse, y que el estado está legitimado para hacerla efectiva, incluso mediante la coerción.


        .row.mb-5
          .col-lg-3.mb-3.mb-lg-0 
            figure
              img.img-a.img-t(src="@/assets/curso/temas/15.png", data-aos="zoom-in")            
          .col-lg-9.j1
            p(data-aos="fade-down") Este poder del Estado no es absoluto. Está regulado por un conjunto de normas jurídicas que aseguran que su ejercicio sea imparcial, legal, y respetuoso de los derechos fundamentales. De ahí que la jurisdicción solo se ejerza a través del proceso judicial, donde las partes tienen oportunidad de presentar pruebas, controvertir argumentos, y ser oídas ante un juez independiente. El respeto por principios como el debido proceso, la igualdad de las partes, la contradicción y la legalidad procesal, son indispensables para que la función jurisdiccional sea legítima.

            .bg-color-5.dot-1.p-4(data-aos="fade-left")
              p.mb-0 Por ejemplo, si una persona es víctima de un incumplimiento contractual, como cuando un comprador no paga lo pactado en la compraventa de un bien inmueble, esa persona puede acudir a un juez civil. Este, al ejercer la jurisdicción, analizará el contrato, evaluará las pruebas y decidirá si procede o no, ordenar el pago o la restitución del bien. Si el juez ordena pagar y la parte vencida no cumple voluntariamente, el mismo aparato judicial puede ordenar embargos o ejecuciones, para que se haga efectiva la sentencia. 


    .row.mb-5         
      .col-lg-8.mb-3.mb-lg-0.j1
        p(data-aos="fade-down") En este sentido, la jurisdicción es la vía institucional que convierte los derechos reconocidos por el Derecho Sustancial en realidades tangibles. Sin ella, los derechos quedarían en el papel, pues no existiría una autoridad imparcial y competente que los hiciera valer frente a los incumplimientos o violaciones. La jurisdicción, entonces, es condición necesaria para que haya justicia, dentro de una sociedad organizada.

        .bg-color-9.p-4(data-aos="fade-left")
          p.mb-0 Además, el ejercicio de la jurisdicción también cumple una función pacificadora y estabilizadora. En lugar de que los conflictos se resuelvan por la fuerza, se canalizan por vías jurídicas, lo cual evita la anarquía y consolida el orden público. Por eso, se afirma que el juez es el órgano por excelencia, que transforma los conflictos sociales en decisiones jurídicas con valor normativo individual (Cifuentes Muñoz, 2006). 

      .col-lg-4 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/16.png", data-aos="zoom-in")   

    .row.align-items-center.mb-5
      .col-lg-auto(data-aos="fade-left")
        img.img-a.img-t(src="@/assets/curso/temas/17.png")
      .col-lg(data-aos="fade-right")
        p.mb-0 En conclusión, la jurisdicción no es solo una herramienta técnica del Derecho Procesal, sino la manifestación concreta del poder del Estado para resolver los conflictos, #[b conforme a la Ley y con pleno respeto por los derechos fundamentales]. Esta función jurisdiccional es el soporte institucional que garantiza que la justicia no sea una aspiración teórica, sino una realidad concreta a la que pueden acudir todos los ciudadanos. 

    #t_1_2.titulo-segundo(data-aos="flip-up")
      h2 #[span 1.2] Características de la jurisdicción

    .bg-color-3.mb-5(data-aos="fade-up")
      .row.justify-content-center.align-items-center
        .col-lg
          .p-4
            p.mb-0(data-aos="fade-down") La jurisdicción, entendida como la potestad del Estado para administrar justicia a través de órganos judiciales institucionalmente establecidos, constituye uno de los pilares fundamentales del orden jurídico en Colombia. Su estudio no se limita a comprenderla como una simple función pública, sino que requiere una visión profunda de sus características esenciales, puesto que estas permiten delimitar su alcance, diferenciarla de otras funciones del Estado y garantizar la protección efectiva de los derechos fundamentales (Garzón Vallejo, 2007).
        .col-lg-auto
          figure
            img(src='@/assets/curso/temas/18.png', alt='')       

    p(data-aos="fade-down") Conozcamos estas características:

    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-4.mb-3.mb-lg-0  
        figure
          img.img-a.img-t(src="@/assets/curso/temas/19.png", alt="")    
      .col-lg-8
        AcordionA(tipo="b")
          .div(titulo="La exclusividad la jurisdicción")
            p Lo que implica que únicamente el Estado tiene la facultad de administrar justicia y dirimir los conflictos jurídicos entre las personas. Esta exclusividad está consagrada en el Artículo 116 de la Constitución Política, el cual establece que la función de administrar justicia se ejerce por jueces y magistrados integrantes de las distintas jurisdicciones, así como por otras autoridades judiciales expresamente autorizadas por la Ley. Aunque existen mecanismos alternativos como la conciliación, el arbitraje y los jueces de paz, estos operan bajo el marco del sistema legal y están subordinados a los principios constitucionales y procesales. Por ejemplo, en un conflicto por el pago de una deuda, solo un juez civil o un árbitro habilitado legalmente puede dictar una decisión que tenga fuerza obligatoria y pueda ejecutarse coactivamente. Ninguna persona, por muy afectada que se sienta, puede hacer justicia por mano propia, porque ello implicaría sustituir ilegalmente la función jurisdiccional del Estado, incurriendo incluso en conductas punibles como la usurpación de funciones públicas o la violencia por vías de hecho.

          .div(titulo="La indelegabilidad de la jurisdicción")
            p Es una consecuencia directa de su exclusividad. Este principio significa que el juez o magistrado, una vez asignado a un proceso, no puede delegar la función de juzgar ni el dictado de la sentencia a otra persona o autoridad. La indelegabilidad garantiza que la decisión judicial sea adoptada por quien tuvo contacto directo con las partes, con las pruebas y con el desarrollo del proceso. Esta regla se conecta con el principio de inmediación, que obliga al juez a estar presente en etapas claves del juicio, como la audiencia de práctica de pruebas, para valorar directamente la credibilidad de los testigos o la autenticidad de los documentos. Por ejemplo, en un proceso penal, el juez que preside la audiencia de juicio oral es el mismo que debe dictar el fallo, debido a que fue quien conoció personalmente la actuación y escuchó los alegatos de las partes. No sería válido, ni legal, que otro juez firmara la sentencia con base en grabaciones o informes, porque se perdería la autenticidad e imparcialidad de la decisión (Garzón Vallejo, 2007).


    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-8.mb-3.mb-lg-0  
        AcordionA(tipo="b")
          .div(titulo="La unidad de la jurisdicción")
            p Lo que significa que, aunque el sistema judicial esté dividido en varias jurisdicciones como la ordinaria, la contenciosa administrativa, la constitucional, la indígena, la penal militar, entre otras, todas ellas hacen parte de un único poder público: la rama judicial del Estado. Esta unidad se manifiesta tanto en el respeto por la jerarquía entre tribunales, como en la existencia de principios comunes que regulan las actuaciones procesales en todas las jurisdicciones. Por ejemplo, los principios de legalidad, contradicción, debido proceso y acceso a la justicia, rigen tanto un proceso laboral como uno penal o administrativo. Así mismo, todas las jurisdicciones están sujetas a la supremacía constitucional y a los límites establecidos por la Corte Constitucional. La unidad del sistema permite también la existencia de mecanismos como el conflicto de competencias y la unificación jurisprudencial, que garantizan coherencia y articulación entre las diferentes ramas del sistema de justicia.

          .div(titulo="la indivisibilidad de la jurisdicción")
            p Una vez que un juez asume el conocimiento de un asunto, debe pronunciarse integralmente sobre todas las pretensiones formuladas por las partes, dentro del proceso. No puede emitir decisiones parciales o fragmentarias que dejen aspectos relevantes sin resolver. Este principio responde a la necesidad de brindar seguridad jurídica, evitar sentencias contradictorias y garantizar la economía procesal. Por ejemplo, si una persona demanda el pago de una indemnización por daño emergente y lucro cesante, derivados de un accidente de tránsito, el juez debe pronunciarse sobre ambos conceptos de manera conjunta, valorando las pruebas y estableciendo con claridad la responsabilidad, los montos y la procedencia de cada uno. No podría decidir sobre el daño emergente y guardar silencio sobre el lucro cesante, pues ello vulneraría el derecho a una tutela judicial efectiva y podría generar nuevas controversias innecesarias (Garzón Vallejo, 2007).

          .div(titulo="la independencia de la jurisdicción")
            p Es quizá la característica más relevante y protectora del sistema judicial. Esta se refiere a la autonomía funcional, decisional y organizativa que debe tener todo juez o tribunal, frente a cualquier tipo de presión externa. Un juez independiente actúa conforme a su criterio jurídico, sin estar subordinado a las órdenes de otras autoridades, ni a intereses políticos, económicos o particulares. Esta independencia es el sustento de la imparcialidad, la legitimidad de las decisiones y la confianza ciudadana en el sistema de justicia. Un ejemplo se presenta cuando un juez debe resolver un proceso en el que el demandado es una entidad estatal o una figura política reconocida. En ese caso, su decisión no puede estar influenciada por presiones mediáticas ni por instrucciones superiores; debe decidir con base en los hechos, el derecho aplicable y las pruebas allegadas al expediente.                                                
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/20.png", alt="")      

    .row.mb-5
      .col-lg-5.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/21.png", data-aos="zoom-in")       
      .col-lg-7
        .bg-color-2.p-4.h-100.j1(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/22.svg")
            .col-lg
              p.mb-0 En conjunto, estas características garantizan que la función jurisdiccional se ejerza dentro de un marco de legalidad, imparcialidad y eficacia. La jurisdicción, como eje del Estado de Derecho, es la vía institucional para resolver los conflictos, proteger los derechos fundamentales y consolidar la paz social. Por ello, su estudio y comprensión resultan inescindibles para todo estudiante y futuro profesional del Derecho, que debe tener la capacidad de comprender el alcance y la trascendencia de esta función en la sociedad democrática.

    #t_1_3.titulo-segundo(data-aos="flip-up")
      h2 #[span 1.3] Órganos jurisdiccionales y sus competencias funcionales según la Ley colombiana
    .row.mb-5    
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-7.p-4.h-100.j1(data-aos="fade-left")
          p.mb-0 En el sistema jurídico colombiano, los órganos jurisdiccionales, son las entidades encargadas de ejercer la función jurisdiccional del Estado, es decir, resolver los conflictos jurídicos mediante decisiones con fuerza de cosa juzgada. Este conjunto de autoridades se encuentra organizado en una estructura jerárquica y especializada que garantiza la adecuada distribución de los asuntos judiciales, conforme a criterios de materia, cuantía, territorio y grado. Estos órganos actúan dentro del marco de la legalidad, conforme a las competencias funcionales establecidas por la Constitución Política y la legislación procesal, principalmente el Código General del Proceso, la Ley Estatutaria de Administración de Justicia y otras leyes sectoriales.
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/23.png", data-aos="zoom-in")   

    p(data-aos="fade-down") En la cúspide del sistema judicial colombiano, se encuentran las altas cortes, que cumplen funciones no solo jurisdiccionales, sino también de unificación jurisprudencial y control constitucional:


    .bg-full-width.bg-fondo-slider.mb-5(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/24.png")        

            .col-lg-7.mb-3.mb-lg-0
              h5 La Corte Suprema de Justicia 
              p Máxima autoridad de la jurisdicción ordinaria, se divide en salas especializadas Civil, Penal y Laboral y se encarga, entre otras funciones, de conocer los recursos de casación y revisar fallos proferidos por los tribunales superiores. Además, actúa como juez de única instancia en procesos penales contra altos funcionarios del Estado, como el presidente de la República o los ministros, conforme al Artículo 235 de la Constitución (Garzón Vallejo, 2007). 

          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/25.png")        

            .col-lg-7.mb-3.mb-lg-0
              h5 La Corte Constitucional 
              p Tiene una función principal de control de constitucionalidad. Esta corte revisa las leyes aprobadas por el Congreso para verificar su conformidad con la Carta Política, ejerce el control automático sobre los decretos legislativos expedidos en estados de excepción, y revisa fallos de tutela cuando estos tengan un impacto significativo en la interpretación de los derechos fundamentales.

          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/26.png")        

            .col-lg-7.mb-3.mb-lg-0
              h5 El Consejo de Estado  
              p Actúa como tribunal supremo de la jurisdicción contencioso-administrativa. Conoce de las controversias entre los particulares y el Estado, resuelve demandas de nulidad contra actos administrativos, y ejerce control sobre la legalidad de normas expedidas por las autoridades administrativas. También cumple funciones consultivas, pues emite conceptos obligatorios sobre proyectos de Ley relacionados con el derecho administrativo y tratados internacionales.                              

    .row.mb-5.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-2.p-4.j1.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/27.svg")
            .col-lg
              p.mb-0 Además de las altas cortes, el sistema judicial colombiano cuenta con tribunales superiores de distrito judicial, que son órganos de segunda instancia en las distintas jurisdicciones ordinarias penal, civil, laboral y de familia. Estos tribunales también cumplen funciones de control disciplinario sobre los jueces del circuito y municipales, y resuelven ciertos recursos extraordinarios.   
        p(data-aos="fade-down") En los niveles inferiores se encuentran los jueces de circuito y municipales, quienes constituyen la base del aparato judicial y conocen la mayoría de los asuntos judiciales en primera instancia:                
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/28.png", data-aos="zoom-in")       

    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-4.mb-3.mb-lg-0  
        figure
          img.img-a.img-t(src="@/assets/curso/temas/29.png", alt="")    
      .col-lg-8
        AcordionA(tipo="b")
          .div(titulo="Jueces municipales")
            p Atienden, por lo general, procesos de menor cuantía, asuntos contravencionales, y tutelas interpuestas por ciudadanos. Un ejemplo sería un proceso verbal sumario para reclamar una deuda inferior a 40 salarios mínimos, el cual es competencia del juez municipal civil. También tienen competencia en algunos procesos penales relacionados con contravenciones menores o delitos de menor impacto.
          .div(titulo="Jueces del circuito")
            p Conocen asuntos de mayor complejidad o de cuantía más alta, así como procesos relacionados con familia, ejecución de penas, laborales, agrarios, entre otros. Por ejemplo, un juez del circuito penal conoce en primera instancia delitos como el homicidio, mientras que el juez de ejecución de penas y medidas de seguridad es responsable de velar por el cumplimiento de las sanciones impuestas, como la reclusión en establecimiento carcelario o la prisión domiciliaria, y de conceder subrogados penales como la libertad condicional.

    .bg-color-2.p-4.dot-2.mb-5(data-aos="fade-left")
      .row.align-items-center
        .col-lg.j1
          p.mb-0 El sistema judicial también incluye jueces especializados que conocen casos específicos conforme a su naturaleza, como los jueces administrativos relaciones entre ciudadanos y entidades públicas, jueces de familia conflictos familiares, custodia, alimentos, jueces laborales derechos derivados del contrato de trabajo, y jueces agrarios conflictos de tierras en zonas rurales.            

        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/30.png")


    .row.mb-5         
      .col-lg-8.mb-3.mb-lg-0.j1
        p(data-aos="fade-down") La distribución funcional de las competencias de estos jueces está determinada por leyes procesales que definen criterios claros sobre quién debe conocer cada asunto. Estos criterios pueden ser objetivos como la naturaleza del litigio, territoriales ubicaciones geográficas del demandado o del hecho, por cuantía valor económico de lo reclamado, o por turno o reparto mecanismo aleatorio para asignar equitativamente procesos entre despachos de igual competencia. Por ejemplo, si un ciudadano demanda a otro por incumplimiento contractual en una compraventa de alto valor económico, el conocimiento del proceso corresponde a un juez civil del circuito ubicado en el domicilio del demandado.

        .bg-color-9.p-4(data-aos="fade-left")
          p.mb-0 En suma, el sistema #[b judicial colombiano] cuenta con un conjunto organizado y jerarquizado de órganos jurisdiccionales que actúan bajo principios de especialidad, competencia, legalidad y transparencia.

      .col-lg-4 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/31.png", data-aos="zoom-in")  

    .bg-full-width.bg-color-3.p-4.mb-5(data-aos="fade-left")
      .px-4
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/32.svg")
          .col-lg
            p.mb-0 Comprender qué órgano conoce cada tipo de asunto, es primordial para garantizar el derecho de acceso a la justicia, evitar nulidades procesales y asegurar que los conflictos jurídicos se resuelvan por autoridades competentes, legítimas y bien capacitadas.

    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.scielo.cl/scielo.php?script=sci_arttext&pid=S0718-33992017000100004" target="_blank" rel="noopener noreferrer") Nieva Fenoll, Jordi. (2017). Seis conceptos en busca de un objetivo: jurisdicción, acción, proceso, derechos, pena y delito. Política criminal, 12(23), 103-123.  
            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="www.redalyc.org/pdf/197/19780115.pdf" target="_blank" rel="noopener noreferrer") Cifuentes Muñoz, E., (2002). JURISDICCIÓN CONSTITUCIONAL EN COLOMBIA. Ius et Praxis, 8(1), 283-317.             

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=w1DRRFmKsdE" target="_blank" rel="noopener noreferrer") EL DERECHO ES PARA TODOS José Francisco Báez Corona (El Derecho es para todos). (2021). JURISDICCIÓN Y COMPETENCIA: Definición, diferencia y criterios.
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=_KnXgfBEvds" target="_blank" rel="noopener noreferrer") Andrés Monzón. (2024). CONFLICTOS DE JURISDICCIÓN.
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=RO6IE9GpVQY" target="_blank" rel="noopener noreferrer") videoconferencias. (2013). UTPL JURISDICCIÓN [(ABOGACÍA)(DERECHO PROCESAL CIVIL I)]                           

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema1',
  data: () => ({}),

  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
