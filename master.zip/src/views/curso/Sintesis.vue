<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up") La Unidad 2: Jurisdicción y competencia, desarrolla conceptos claves del Derecho Procesal que permiten comprender el ejercicio legítimo de la función jurisdiccional por parte del Estado. A través del análisis de la jurisdicción como manifestación del poder público y de la competencia como distribución legal de esa función entre los diferentes jueces, esta unidad proporciona herramientas fundamentales para interpretar el funcionamiento del sistema judicial colombiano.

      p(data-aos="fade-up").mb-5 El estudio de los criterios de asignación de competencia, los impedimentos y recusaciones, así como de los conflictos de competencia y el principio del juez natural, fortalece la comprensión del debido proceso y la imparcialidad judicial. Este enfoque asegura que los estudiantes adquieran una base sólida sobre los órganos que administran justicia, preparándolos para aplicar estos conocimientos en la práctica profesional y en la resolución jurídica de controversias.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
